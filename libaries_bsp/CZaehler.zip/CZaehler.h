
class CZaehler
{
  private:
    int zaehler;

  public:
    Czaehler();
    void erhoehe();
    int getzaehlerstand();
    

  
};
